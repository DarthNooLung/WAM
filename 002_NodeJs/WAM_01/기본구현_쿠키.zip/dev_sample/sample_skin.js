﻿if (typeof NetFunnel == "object") {
    NetFunnel.SkinUtil.add('test', {
        htmlStr: '<div id="NetFunnel_Skin_Top" style="background-color:#ffffff;border:1px solid #9ab6c4;width:458px;-moz-border-radius: 5px; -webkit-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px;">\
	        <div style="background-color:#ffffff;border:6px solid #eaeff3;-moz-border-radius: 5px; -webkit-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px;">\
		        <div style="text-align:right;padding-top:5px;padding-right:5px;line-height:25px;">\
		        <b><span id="NetFunnel_Loding_Popup_Debug_Alerts" style="text-align:left;color:#ff0000"></span></b>\
		        <span style="text-align:right;">\
		        <b style="font-size:12px;"></b><img style="height:25px;color:black;font-size:11px;" border=0 src="https://ehrx.hdec.co.kr/HDECHR.WebUI/images/login_ci.jpg" >\
		        </span></div>\
		        <div style="padding-top:0px;padding-left:25px;padding-right:25px">\
			        <div style="text-align:left;font-size:12pt;color:#001f6c;height:22px"><b>서비스 <span style="color:red"><blink>접속대기 중 </blink></span>입니다.</b></div>\
                    <div style="text-align:right;font-size:10pt;color:#4d4b4c;padding-top:4px;height:17px" ><b>예상대기시간 : <span style="color:#013dc1"> <span id="NetFunnel_Loading_Popup_TimeLeft"></span> </span></b></div>\
			        <div style="text-align:right;font-size:10t;color:#4d4b4c;padding-top:4px;height:17px" ><b>앞에 <span style="color:#013dc1"><span id="NetFunnel_Loading_Popup_Count"></span>명</span>의 대기자가 있습니다.</b></div>\
			        <div style="padding-top:6px;padding-bottom:6px;vertical-align:center;width:400px" id="NetFunnel_Loading_Popup_Progressbar"></div> \
			        <div style="background-color:#ededed;width:400px;padding-bottom:8px;overflow:hidden">\
				        <div style="padding-left:5px">\
					        <div style="text-align:left;font-size:8pt;color:#4d4b4c;padding:3px;height:10px">현재 접속 사용자가 많아 대기 중이며, 잠시만 기다리시면 </div>\
					        <div style="text-align:left;font-size:8pt;color:#4d4b4c;padding:3px;height:10px;">서비스로 자동 접속 됩니다.</div>\
					        <div style="text-align:left;font-size:9pt;color:#2a509b;padding-top:10px;">\
						        <b>※ 재 접속하시면 대기시간이 더 길어집니다.  </b>\
					        </div>\
				        </div>\
			        </div>\
			        <div style="height:5px;"></div>\
		        </div>\
	        </div>\
        </div>'

    }, 'normal');
}