/*
참고 사이트
1 : https://3dmpengines.tistory.com/1971
*/